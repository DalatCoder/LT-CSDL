﻿namespace Lab02_GiaoVien
{
    public enum KieuTim
    {
        TheoMa,
        TheoHoTen,
        TheoSDT
    }
}
