﻿namespace Lab02_GiaoVien
{
    internal class DialogSettingsCancel
    {
        public DialogSettingsCancel()
        {
        }
    }
}